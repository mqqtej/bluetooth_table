package com.droiduino.bluetoothconn;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Bitmap;
import android.graphics.Color;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class krugboja extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_krugboja);

        final Bitmap[] bitmap = new Bitmap[1];
        TextView textView;
        View va;
        ImageView imageView;

        imageView=(ImageView) findViewById(R.id.odabirBoja);
        textView=(TextView) findViewById(R.id.textView);
        va=(View) findViewById(R.id.prikazBoja);



        imageView.setDrawingCacheEnabled(true);
        imageView.buildDrawingCache(true);



        imageView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (event.getAction() == MotionEvent.ACTION_DOWN || event.getAction() == MotionEvent.ACTION_MOVE){
                    bitmap[0] = imageView.getDrawingCache();
                    int pixel = bitmap[0].getPixel((int)event.getX(), (int)event.getY());

                    int r = Color.red(pixel);
                    int g = Color.green(pixel);
                    int b = Color.blue(pixel);

                    String hex = "#"+ Integer.toHexString(pixel);
                    va.setBackgroundColor(Color.rgb(r,g,b));
                    textView.setText("RGB: "+r+", "+g+", "+b+"  \nHEX:" + hex);
                    String x = String.format("%03d",r);
                    String y = String.format("%03d",g);
                    String z = String.format("%03d",b);
                    String s = "1R"+x+"G"+y+"B"+z;

                    MainActivity.connectedThread.write(s);
                }
                return true;
            }
        });
    }
}