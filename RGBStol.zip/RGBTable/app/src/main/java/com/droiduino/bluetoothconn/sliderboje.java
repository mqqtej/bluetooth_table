package com.droiduino.bluetoothconn;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;

public class sliderboje extends AppCompatActivity {

    int r,g,b;
    SeekBar sb1, sb2, sb3;
    Button stisni;
    TextView text;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sliderboje);


        stisni = (Button) findViewById(R.id.Stisni1);
        text = (TextView) findViewById(R.id.textView5);
        sb1 = (SeekBar) findViewById(R.id.seekBar1);
        sb2 = (SeekBar) findViewById(R.id.seekBar2);
        sb3 = (SeekBar) findViewById(R.id.seekBar3);

        stisni.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                r=sb1.getProgress();
                g=sb2.getProgress();
                b=sb3.getProgress();
                text.setText("R: "+r+" G: "+g+" B: "+b);
                String x = String.format("%03d",r);
                String y = String.format("%03d",g);
                String z = String.format("%03d",b);
                String s = "1R"+x+"G"+y+"B"+z;
                MainActivity.connectedThread.write(s);
            }
        });
    }
}