package com.droiduino.bluetoothconn;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.Random;

public class nasumicneboje extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nasumicneboje);
        Button stisni;
        TextView text;
        View va;


        stisni=(Button)findViewById(R.id.Stisni2);
        text=(TextView)findViewById(R.id.textView4);
        va=(View)findViewById(R.id.view);
        Random random = new Random();
        stisni.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int x = random.nextInt(3);
                if(x==0)
                {
                    va.setBackgroundColor(getResources().getColor(R.color.red));
                    String s = "1R255G000B000";
                    MainActivity.connectedThread.write(s);
                    text.setText("BOJA: CRVENA");
                }
                if(x==1)
                {
                    va.setBackgroundColor(getResources().getColor(R.color.green));
                    String s = "1R000G255B000";
                    MainActivity.connectedThread.write(s);
                    text.setText("BOJA: ZELENA");
                }
                if(x==2)
                {
                    va.setBackgroundColor(getResources().getColor(R.color.blue));
                    String s = "1R000G000B255";
                    MainActivity.connectedThread.write(s);
                    text.setText("BOJA: PLAVA");
                }





            }
        });
    }
}